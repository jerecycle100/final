Code for the Final Exam
